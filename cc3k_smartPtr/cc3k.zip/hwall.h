#ifndef _HWALL_H_
#define _HWALL_H_

#include "object.h"

class Hwall: public Object {
 public:
  Hwall(int x, int y);
  ~Hwall();
};

#endif
