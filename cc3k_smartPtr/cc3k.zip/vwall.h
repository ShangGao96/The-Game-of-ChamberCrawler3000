#ifndef _VWALL_H_
#define _VWALL_H_

#include "object.h"

class Vwall: public Object {
 public:
  Vwall(int x, int y);
  ~Vwall();
};

#endif
